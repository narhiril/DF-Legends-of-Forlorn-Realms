Included are support files for a few popular graphic sets.

This folder contains a variety of files that correspond to graphic sets.  To use one
of these, first...

1) Install DF with the graphics set you want to use
2) Install LFR
3) Drag the file in this folder that corresponds to your chosen graphics set into the graphics folder (parent directory of this folder).

For example, if you are using Ironhan'd graphics set, drag "graphics_lfr_ironhand.txt" out of this folder and into DF's raw/graphics folder.

You should only need one of the files in this folder at a time, unless you are mixing graphic sets, in which case you probably can figure out
how to make it work on your own.

4) Load up and enjoy!

Current supported graphics sets:
Ironhand