This mini-mod (by Sphalerite of the Bay12 Forums) makes animal men and giant creatures much rarer then they are by default in 0.34.02.

To install, drag and drop into your df/raw folder.

Yes, I know, this is the shortest readme ever.